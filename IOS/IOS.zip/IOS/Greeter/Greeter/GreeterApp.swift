//
//  GreeterApp.swift
//  Greeter
//
//  Created by R C Schweickhardt on 9/22/21.
//

import SwiftUI

@main
struct GreeterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
