//
//  ContentView.swift
//  Greeter
//
//  Created by R C Schweickhardt on 9/22/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var count = 0
    @State private var reduceCount = false
    @State private var increaseCount = false
    @State private var name = ""
    @State private var showingAlert = false
    
    var body: some View {
        
        VStack {
            ButtonView(count: $count, reduceCount: $reduceCount, increaseCount: $increaseCount)
            
            CountView(count: $count, reduceCount: $reduceCount, increaseCount: $increaseCount)
            
            Spacer()
            
            HStack{
                Text("Name:")
                    .fontWeight(.bold)
                    .font(.title)
                TextField("", text: $name, onEditingChanged: {_ in
                    
                }){
                    showingAlert = true
                }
                .textFieldStyle(.roundedBorder)
                .alert(isPresented: $showingAlert) {
                    Alert(title: Text("Greetings \(name)"), message: Text("How are you doing today?"), dismissButton: .default(Text("I'm Fine!"), action: {name = ""}))
                }
                
            }
            .padding()

            Spacer()
        }//VStack
        
    }//body
}//struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ButtonView: View {
    
    @Binding var count: Int
    @Binding var reduceCount: Bool
    @Binding var increaseCount: Bool
    
    var body: some View {
        HStack{
            Button{
                
                count += 1
                if count >= 10 {
                    reduceCount = true
                }
                if count >= 0 {
                    increaseCount = false
                }
                
            }label: {
                Text("+")
                    .foregroundColor(.white)
                    .frame(width: 150, height: 150)
                    .background(Color.green)
                    .cornerRadius(10)
            }//Button +
            Button{
                
                count -= 1
                if count <= 9 {
                    reduceCount = false
                }
                if count <= -1 {
                    increaseCount = true
                }
                
            }label: {
                Text("-")
                    .foregroundColor(.white)
                    .frame(width: 150, height: 150)
                    .background(Color.red)
                    .cornerRadius(10)
                
            }//Button -
            
        }
    }
}

struct CountView: View {
    
    @Binding var count: Int
    @Binding var reduceCount: Bool
    @Binding var increaseCount: Bool
    
    var body: some View {
        ZStack {
            Text("Count: \(count)")
                .font(.title)
                .fontWeight(.bold)
                .frame(width: 300, height: 100)
                .background(reduceCount||increaseCount ? Color.red : Color.white)
            Text(reduceCount ? "Reduce your count!" : "")
                .font(.footnote)
                .foregroundColor(.white)
                .background(Color.yellow)
                .offset(x: 0, y: 50)
            Text(increaseCount ? "Increase your count!" : "")
                .font(.footnote)
                .foregroundColor(.white)
                .background(Color.yellow)
                .offset(x: 0, y: 50)
        }
        .padding()
    }
}
