class TipCalculator {
    let total: Double
    let taxPct: Double
    let subTotal: Double
    
    init(total: Double, taxPct: Double){
        self.total = total
        self.taxPct = taxPct
        subTotal = total / (taxPct + 1)
    }//init
    
    func calcTipWith(tipPct: Double) -> Double {
        subTotal * tipPct
    }//calcTipWith
    
    func printPossibleTips(){
//        print("15%: \(calcTipWith(tipPct: 0.15))")
//        print("18%: \(calcTipWith(tipPct: 0.18))")
//        print("20%: \(calcTipWith(tipPct: 0.20))")
        let possibleTips = [0.15,0.18,0.20]
        for possibleTip in possibleTips {
            print("\(possibleTip*100)%: \(calcTipWith(tipPct: possibleTip))")
        }
        
        for i in 0..<possibleTips.count{
            let possibleTip = possibleTips[i]
            print("\(possibleTip*100)%: \(calcTipWith(tipPct: possibleTip))")
        }
    }//printPossibleTips
    
    func returnPossibleTips() -> [Int:Double]{
        let possibleTips = [0.15,0.18,0.20]
        var retVal = Dictionary<Int,Double>() //or [Int:Double]()
        for possibleTip in possibleTips {
            let intPct = Int(possibleTip*100)
            retVal[intPct] = calcTipWith(tipPct: possibleTip)
        }//for possibleTip
        return retVal
    }//returnPossibleTips
    
}//class

let tipCalc = TipCalculator(total: 33.25, taxPct: 0.06)
tipCalc.printPossibleTips()
tipCalc.returnPossibleTips()
