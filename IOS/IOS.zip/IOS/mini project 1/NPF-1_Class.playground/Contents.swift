import CoreLocation

class Park: CustomStringConvertible {
    
    convenience init(){
        self.init(parkName: "Unknown", parkLocation: "Unknown", dateFormed: "Unknown", area: "Unknown", link: "Unknown", location: nil, imageLink: "Unknown", parkDescription: "Unknown")
    }
    
    init(parkName: String, parkLocation: String, dateFormed: String, area: String, link: String, location: CLLocation?, imageLink: String, parkDescription: String){
        self.parkName = parkName
        self.parkLocation = parkLocation
        self.dateFormed = dateFormed
        self.area = area
        self.link = link
        self.location = location
        self.imageLink = imageLink
        self.parkDescription = parkDescription
        let testParkName = parkName.trimmingCharacters(in: .whitespacesAndNewlines)
        let testLocation = parkLocation.trimmingCharacters(in: .whitespacesAndNewlines)
        if testParkName.count < 3 ||  testParkName.count > 75{
            self.parkName = "TBD"
            print("Bad value of \(parkName) in set(parkName): setting to TBD")
        }
        if testLocation.count < 3 ||  testLocation.count > 75{
            self.parkLocation = "TBD"
            print("Bad value of \(parkLocation) in set(parkLocation): setting to TBD")
        }
    }
    
    var description: String {
        return """
        {
        parkName: \(parkName)
        parkLocation: \(parkLocation)
        dateFormed: \(dateFormed)
        area: \(area)
        link: \(link)
        location: \(location)
        imageLink: \(imageLink)
        parkDescription: \(parkDescription)
        }
        """
    }
    
    private var parkName : String = ""
    private var parkLocation : String = ""
    private var dateFormed : String = ""
    private var area : String = ""
    private var link : String = ""
    private var location : CLLocation?
    private var imageLink : String = ""
    private var parkDescription : String = ""
        
    func getParkName() -> String {
        parkName
    }
        
    func setName(name: String) {
        parkName = name
    }
    
    func getParkLocation() -> String {
        parkLocation
    }
        
    func setParkLocation(location: String) {
        parkLocation = location
    }
    
    func getDateFormed() -> String {
        dateFormed
    }
        
    func setDateFormed(date: String) {
        dateFormed = date
    }
    
    func getArea() -> String {
        area
    }
        
    func setArea(area1: String) {
        area = area1
    }
    
    func getLink() -> String {
        link
    }
        
    func setLink(link1: String) {
        link = link1
    }
    
    func getLocation() -> CLLocation {
        location!
    }
        
    func setLocation(location1: CLLocation) {
        location = location1
    }
    
    func getImageLink() -> String {
        imageLink
    }
        
    func setImageLink(image: String) {
        imageLink = image
    }
    
    func getParkDescription() -> String {
        parkDescription
    }
        
    func setParkDescription(description: String) {
        parkDescription = description
    }
}

let p1 : Park = Park()
let p2 : Park = Park(parkName: "Acadia National Park", parkLocation: "Maine", dateFormed: "1919-02-26", area: "47,389.67 acres (191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD")

print("\(p1)")
print("\(p2)")
p2.setLink(link1: "http://en.wikipedia.org/wiki/Acadia_National_Park")
print("\(p2)")
let p3 = Park(parkName: "ab", parkLocation: "na", dateFormed: "1919-02-26", area: "47,389.67 acres (191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD")
print("\(p3)")
