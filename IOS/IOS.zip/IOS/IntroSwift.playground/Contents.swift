let tutorialTeam:Int = 56
let editorialTeam = 23
var totalTeam = tutorialTeam + editorialTeam
totalTeam += 1

let price = 19.99
let onSale = false

let name = "Slinky"
let name2 = """
    line 1
line2
    line3
"""
if onSale {
    print("\(name) on sale for \(price)")
} else {
    print("\(name) not on sale for \(price)")
}
print("a", terminator: ",")
print("b")
