//let name:String? = "Arthur Dent"
//print(name)
//
//let score:Int = nil
//print(score)

class Vehicle{
    var wheels: Int = 4
    var name: String?
    var owner: Person?
}

let car = Vehicle()
print(car.wheels)
print(car.name)

car.name = "Maserati"
print(car.name)

//let email:String? = "thadsvsd@gmail.com"
//let email:String? = nil

//if email != nil {
//    print(email!)
//}

let optionalUsername: String? = "rcs5166"

if let username = optionalUsername{
    print(username)
}


let firstname:String? = "first"
let lastname:String? = "last"
let email:String? = "email"

if let first_name = firstname,
   let last_name = lastname,
   let email = email {
    print("Got it all!")
}

if let score = Int("abc"){
    print(score)
}

func testGuard(userName:String?){
    guard let username = userName else {
        return
    }
    print("Logged in user with username: \(username)")
}

testGuard(userName: "rcs5166")

class DriversLicense{
    var pointOnLicence = 0
    
    func isValidFor(vehicle: Vehicle) -> Bool{
        true
    }
}
class Person{
    var license:DriversLicense?
}

let Andy = Person()

//optional binding
if let license = Andy.license{
    print("Andy has \(license.pointOnLicence) points")
} else {
    print("Andy doesn't have a drivers license")
}

//force unwrapping
if Andy.license != nil{
    print("Andy has \(Andy.license!.pointOnLicence) points")
} else {
    print("Andy doesn't have a drivers license")
}


//optional chaining
let poinsOnLicense = Andy.license?.pointOnLicence
if let points = poinsOnLicense{
    print("Andy has \(points) points")
} else {
    print("Andy doesn't have a drivers license")
}

var points = 3
Andy.license?.pointOnLicence = points
Andy.license = DriversLicense()
let car2 = Vehicle()
car2.owner = Andy

if let canDriveVehicle = Andy.license?.isValidFor(vehicle: car2){
    if canDriveVehicle{
        print("Andy's license allows him to drive the car")
    } else {
        print("Andy's license doesn't allows him to drive the car")
    }
} else {
    print("Andy doesn't have a license")
}

if let result = Andy.license?.pointOnLicence += points{
    print("Andy now has \(Andy.license!.pointOnLicence) points")
}

var catolog = ["Honda" : (minPrice: 10, MaxPrice: 100)]

var honda = catolog["Honda"]

if let price = catolog["Honda"]?.minPrice{
    print("the min prince is \(price)")
}

if let price = catolog["Honda"]?.MaxPrice = 30{
    print("\(catolog)")
}

var otherCatolog : Dictionary? = ["Lotus": (minPrice: 50, MaxPrice: 200)]

var lotus = otherCatolog?["Lotus"]
if let price = otherCatolog?["Lotus"]?.minPrice{
    print("min price \(price)")
}



var minPrice = catolog["Lotus"]?.minPrice ?? 0
print("The minumum price is \(minPrice)")
minPrice = catolog["Honda"]?.minPrice ?? 0
print("The minumum price is \(minPrice)")

//implicitly wrapped optional
var usernameFaild: String!
