//
//  _54FinalSchweickhardtApp.swift
//  454FinalSchweickhardt
//
//  Created by R C Schweickhardt on 12/2/21.
//

import SwiftUI

@main
struct _54FinalSchweickhardtApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
