//
//  ContentView.swift
//  454FinalSchweickhardt
//
//  Created by R C Schweickhardt on 12/2/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            MovieView()
                .tabItem {
                    Image(systemName: "film.fill")
                    Text("Movie")
                }
            MapView()
                .tabItem {
                    Image(systemName: "map.fill")
                    Text("Map")
                }
            ConvertView()
                .tabItem {
                    Image(systemName: "wrench.fill")
                    Text("Converter")
                }
            AboutView()
                .tabItem {
                    Image("85-trophy")
                    Text("About")
                }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
