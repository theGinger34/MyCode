//
//  MovieView.swift
//  MovieView
//
//  Created by R C Schweickhardt on 12/2/21.
//

import SwiftUI
import UIKit

struct MovieView: View {
    
    struct Movies {
        var rating: String
        var title: String
        var description: String
    }
    @State var movieList : [Movies]
    
    func getMovies() {
        guard let path = Bundle.main.path(forResource: "movies", ofType: "plist") else {return}
        let url = URL(fileURLWithPath: path)
        let data = try! Data(contentsOf: url)
        guard let plist = try! PropertyListSerialization.propertyList(from: data, options: [], format: nil) as? Movies else {return}
        movieList = [plist]
        print(movieList)
        
    }//init
    
    var body: some View {
        Text("HI")
}

struct MovieView_Previews: PreviewProvider {
    static var previews: some View {
        MovieView(movieList: [Movies])
    }
    }
}
