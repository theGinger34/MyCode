//
//  AboutView.swift
//  AboutView
//
//  Created by R C Schweickhardt on 12/2/21.
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        ZStack {
            Color.red
            .edgesIgnoringSafeArea(.top)
            Text("Campbell Schweickhardt")
                .fontWeight(.bold)
                .font(.title)
                
        }
    }
}

struct AboutView_Previews: PreviewProvider {
    static var previews: some View {
        AboutView()
    }
}
