//
//  NPF__2App.swift
//  NPF--2
//
//  Created by R C Schweickhardt on 10/9/21.
//

import SwiftUI

@main
struct NPF__2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
