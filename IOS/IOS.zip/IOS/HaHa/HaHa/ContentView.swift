//
//  ContentView.swift
//  HaHa
//
//  Created by R C Schweickhardt on 9/21/21.
//

import SwiftUI
import AVFoundation

struct ShakeEffect: GeometryEffect{
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: -30 * sin(position * 2 * .pi), y: 0))
    }
    
    init(shakes:Int){
        position = CGFloat(shakes)
    }
    
    var position: CGFloat
    var animatableData: CGFloat{
        get {position}
        set {position = newValue}
    }
    
}//ShakeEffect

struct ContentView: View {
    
    @State private var count = 0
    
    var body: some View {
        
        Color.blue
            .overlay(
                VStack {
                    
                    ButtonRow(count: $count)
                    
                    Spacer()
                    
                    Text("HA HA # \(count)")
                        .font(.system(size: 50))
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                    
                    
                    Spacer()
                    Image("nelson")
                        .resizable()
                    .aspectRatio(contentMode: .fit)
                }//VStack
                
//                Image("nelson")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: 300)
//                    .overlay(
//                        Rectangle()
//                            .foregroundColor(.black)
//                            .opacity(0.4)
//                            .overlay(
//                                Text("Nelson")
//                                    .font(.largeTitle)
//                                    .fontWeight(.black)
//                                    .foregroundColor(.white)
//                                    .frame(width: 200)
//                            )
//                    )//overlay
//            Image("nelson")
//                .resizable()
//                .aspectRatio(contentMode: .fill)
//                .frame(width: 300)
//                //.clipped()
//                .clipShape(Circle())
//                .overlay(
//                    Text("Watch out for Nelson!")
//                        .fontWeight(.heavy)
//                        .font(.system(.headline, design: .rounded))
//                        .foregroundColor(.white)
//                        .padding()
//                        .background(Color.black)
//                        .cornerRadius(10)
//                        .opacity(0.8)
//                        .padding(),alignment: .bottom
//                    Image(systemName:"heart.fill")
//                        .font(.system(size: 50))
//                        .foregroundColor(.black)
//                        .opacity(0.5)
//                )
//
//                .opacity(0.5)
//                .scaledToFit()
//                .edgesIgnoringSafeArea(.all)
        )
            .edgesIgnoringSafeArea(.vertical)
//        Image(systemName: "cloud.heavyrain")
//            .font(.system(size: 100))
//            .foregroundColor(.blue)
//            .shadow(color: .gray, radius: 10, x: 0, y: 10)
    }//body
}//Struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct ButtonRow: View {
    
    @Binding var count: Int
    @State private var shakeit = false
    @StateObject private var myPlayer = MyPlayer()
    
    var body: some View {
        HStack{
            
            Button {
                if myPlayer.player != nil {
                    count += 1
                    shakeit.toggle()
                    myPlayer.player?.play()
                    AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                }
            } label: {
                Image("bart_button")
                    .modifier(ShakeEffect(shakes: shakeit ? 2 : 0))
                    .animation(.linear, value: shakeit)
            }
            .buttonStyle(PlainButtonStyle())
            
            Spacer()
            
            Button {
                if myPlayer.player != nil {
                    count -= 1
                    shakeit.toggle()
                    myPlayer.player?.stop()
                    AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                }
            } label: {
                Image("ralph_button")
                    .modifier(ShakeEffect(shakes: shakeit ? 2 : 0))
                    .animation(.linear, value: shakeit)
            }
            .buttonStyle(PlainButtonStyle())
            
        }//HStack
        .padding(30)
    }
}
