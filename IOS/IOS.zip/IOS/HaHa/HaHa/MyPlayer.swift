//
//  MyPlayer.swift
//  MyPlayer
//
//  Created by R C Schweickhardt on 9/22/21.
//

import Foundation
import AVFoundation

class MyPlayer : ObservableObject{
    
    @Published var player: AVAudioPlayer? = nil
    
    let HA_HA_FILE = "haha"
    let HA_HA_FORMAT = "mp3"
    
    init() {
        
        if let soundFilePath = Bundle.main.path(forResource: HA_HA_FILE, ofType: HA_HA_FORMAT) {
            
            let fileURL = URL(fileURLWithPath: soundFilePath)
            
            do{
                
                player = try AVAudioPlayer(contentsOf: fileURL)
                
            } catch {
                player = nil
                print(error)
            }
            
        }//if let
        
        player?.prepareToPlay()
        
    }//init
    
}
//MyPlayer
