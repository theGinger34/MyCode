//
//  HaHaApp.swift
//  HaHa
//
//  Created by R C Schweickhardt on 9/21/21.
//

import SwiftUI

@main
struct HaHaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
