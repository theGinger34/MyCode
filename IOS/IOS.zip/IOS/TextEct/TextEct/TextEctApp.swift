//
//  TextEctApp.swift
//  TextEct
//
//  Created by R C Schweickhardt on 9/20/21.
//

import SwiftUI

@main
struct TextEctApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
            //TextFeildExample()
            //FormExample()
            ButtonsExample()
            //MoreButtons()
        }
    }
}
