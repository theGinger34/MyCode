//
//  MoreButtons.swift
//  MoreButtons
//
//  Created by R C Schweickhardt on 9/21/21.
//

import SwiftUI

struct MoreButtons: View {
    
    let gradient = LinearGradient(gradient: Gradient(colors:[Color.red,Color.blue]), startPoint: .topLeading, endPoint: .bottomTrailing)
    
    var body: some View {
        VStack {
            
            Button{
                
            } label: {
                Text("The Solid")
                    .foregroundColor(Color.white)
                    .padding()
            }
            .background(RoundedRectangle(cornerRadius: 10, style: .continuous))
            
            
            Button{
                
            } label: {
                Text("The Outline")
                    .padding()
            }
            .background(Capsule()
                            .stroke(lineWidth: 2))
            
            Button{
                
            }label:{
                Text("The Translucent")
                    .padding()
            }
            .background(RoundedRectangle(cornerRadius: 15).opacity(0.2))
            
            Button{
                
            } label: {
                Text("The Gradient")
                    .padding()
            }
            .background(Capsule()
                            .stroke(gradient,lineWidth: 2)
                            .saturation(1.8))
            
            Button("Add"){
                
            }//Button Add
            .tint(.green)
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            Button("Subtract"){
                
            }//Button Subtract
            .tint(.blue)
            Button("Multiply"){
                
            }//Button Multiply
            .tint(.red)
            Button("Divide"){
                
            }//Button Divide
            .tint(.purple)
        }//VStack
        .buttonStyle(.bordered)
        //.tint(.green)
        .controlSize(.small)
        
    }//body
}//struct

struct MoreButtons_Previews: PreviewProvider {
    static var previews: some View {
        MoreButtons()
    }
}
