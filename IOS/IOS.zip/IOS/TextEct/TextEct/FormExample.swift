//
//  FormExample.swift
//  FormExample
//
//  Created by R C Schweickhardt on 9/21/21.
//

import SwiftUI

struct FormExample: View {
    
    @State private var name = ""
    @State private var location = ""
    @State private var date = Date()
    @State private var hasNextField = false
    @State private var hasPreviousField = true
    
    var body: some View {
        Form{
            TextField("Name", text: $name, prompt: Text("Enter Name"))
                .submitLabel(.next)
                .onSubmit {
                    print("name submitted")
                }
            TextField("Location", text: $location)
            DatePicker("Date", selection: $date)
        }//form
        .toolbar{
            ToolbarItemGroup(placement: .keyboard) {
                Button(action: selectPreviousField){
                    Label("Previous", systemImage: "chevron.up")
                }//button
                .disabled(!hasPreviousField)
                
                Button(action: selectNextField){
                    Label("Next", systemImage: "chevron.down")
                }//button
                .disabled(!hasNextField)
            }//toolbarItemGroup
        }//toolbar
    }//body
    private func selectPreviousField(){
        
    }//selectPreviousField
    private func selectNextField(){
        
    }//selectNextField
}//struct

struct FormExample_Previews: PreviewProvider {
    static var previews: some View {
        FormExample()
    }
}
