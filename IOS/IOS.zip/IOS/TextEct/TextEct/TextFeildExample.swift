//
//  TextFeildExample.swift
//  TextFeildExample
//
//  Created by R C Schweickhardt on 9/21/21.
//

import SwiftUI

struct SuperCustomTextFeildStyle: TextFieldStyle{
    
    func _body(configuration: TextField<_Label>) -> some View{
        
        configuration
            .padding()
            .background(Color.blue)
            .foregroundColor(Color.white)
            .cornerRadius(15.0)
    }
}

struct TextFeildExample: View {
    
    @State var username:String=""
    
    var body: some View {
        VStack {
            Text("Enter Name:")
                .fontWeight(.bold)
                .font(.title)
                .foregroundColor(.gray)
            
            TextField("Enter username...", text: $username, onEditingChanged: { changed in
                print("Username onEdittingChanged - \(changed)")
            }){
                print("username onCommit")
            }
            .textFieldStyle(SuperCustomTextFeildStyle())
//            .foregroundColor(Color.white)
//            .background(Color.blue)
//            .cornerRadius(5.0)
            //.textFieldStyle(RoundedBorderTextFieldStyle())
            .keyboardType(.default)
            .textContentType(.name)
            
            Text("Your username: \(username)")
        }//VStack
        .padding()
    }//body
}//TextFeildExample

struct TextFeildExample_Previews: PreviewProvider {
    static var previews: some View {
        TextFeildExample()
    }
}
