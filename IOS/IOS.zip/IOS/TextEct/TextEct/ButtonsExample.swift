//
//  ButtonsExample.swift
//  ButtonsExample
//
//  Created by R C Schweickhardt on 9/21/21.
//

import SwiftUI

let gradient = LinearGradient(gradient: Gradient(colors:[Color.red,Color.blue]), startPoint: .topLeading, endPoint: .bottomTrailing)

struct ButtonsExample: View {
    
    @State var username = ""
    @State private var showText = false
    @State private var showingAlert = false
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            UsernameView(username: $username, showText: $showText, showingAlert: $showingAlert)
            Spacer()
            
            Button(action: {
                print("Button action")
                //showText.toggle()
                showingAlert = true
            }){
                ZStack {
                    GreetButtonView()
                    Text("Say Hello!")
                        .font(.system(.caption, design: .rounded))
                        .fontWeight(.bold)
                        .foregroundColor(Color.white)
                        .padding(5)
                        .background(Color(red: 255/255, green: 183/255, blue: 37/255))
                        .offset(x: 0, y: 25)
                }
            }//button lable
            .shadow(color: .blue, radius: 10.0)
            .alert(isPresented: $showingAlert) {
                //Alert(title: Text("Hey There!"), message: Text("Hello \(username)"), dismissButton: .default(Text("Goodbye!")))
                Alert(title: Text("Geetings \(username)"), message: Text("Are you sure you want to say goodbye?"), primaryButton: .destructive(Text("No"), action: {print("I don't want to say goodbye!")}), secondaryButton: .cancel(Text("Yes!"), action: {print("Saying goodbye!")}))
            }
            Text("Your username: \(username)")
                .opacity(showText ? 1.0 : 0.0)
        }//VStack
        .padding()
    }//body
}//struct

struct ButtonsExample_Previews: PreviewProvider {
    static var previews: some View {
        ButtonsExample()
    }
}

struct UsernameView: View {
    
    @Binding var username: String
    @Binding var showText: Bool
    @Binding var showingAlert: Bool
    
    var body: some View {
        HStack {
            Text("Enter Name:")
                .fontWeight(.bold)
                .font(.title)
                .foregroundColor(.gray)
            
            TextField("Enter username...", text: $username, onEditingChanged: { changed in
                print("Username onEdittingChanged - \(changed)")
            }){
                print("username onCommit")
                //showText.toggle()
                showingAlert = true
            }
            .textFieldStyle(SuperCustomTextFeildStyle())
        }
    }
}

struct GreetButtonView: View {
    var body: some View {
        HStack{
            Image(systemName: "captions.bubble.fill")
            Text("Greet")
                .foregroundColor(Color.white)
        }//HStack
        //.frame(minWidth: 0, maxWidth: .infinity, minHeight: 200)
        .padding(10)
        .background(Capsule()
                        .fill(gradient)
                        .overlay(
                            Capsule()
                                .stroke(gradient,lineWidth: 2)
                        ))
    }
}
