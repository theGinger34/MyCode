//
//  ContentView.swift
//  TextEct
//
//  Created by R C Schweickhardt on 9/20/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tincidunt pulvinar dolor sed efficitur. In consequat magna eget turpis volutpat, posuere laoreet sem dapibus. Nulla quis luctus mauris, at bibendum magna. Nam venenatis urna nec mi malesuada lacinia. Maecenas ac purus id felis hendrerit laoreet a ut nisl. Donec non elementum tortor. Donec urna nulla, commodo ut nibh ac, mollis sodales nulla. Proin sed dolor elementum, mattis est sit amet, convallis diam. Aliquam a nunc enim. Quisque pharetra leo eget felis pretium, vitae mollis purus pulvinar. Sed vitae quam fermentum, mattis augue in, posuere diam. Nulla tincidunt gravida tellus et consequat. Aenean nec elit nec mauris pretium interdum ut non ex. Quisque pharetra viverra ante, sit amet dignissim augue auctor sit amet. Morbi tempor libero quis augue fermentum, eu auctor nisl lacinia. Phasellus nec egestas justo, eget finibus nibh.")
            .fontWeight(.heavy)
            //.font(.title)
            //.font(.system(.largeTitle, design: .rounded))
            //.font(.system(size: 20))
            .font(.custom("Helvetica Neue", size: 25))
            .foregroundColor(.green)
            .multilineTextAlignment(.leading)
            .lineLimit(5)
            .lineSpacing(10)
            .truncationMode(.middle)
            //.rotationEffect(.degrees(45))
            //.rotationEffect(.degrees(20),anchor: UnitPoint(x: 0, y: 0))
            .rotation3DEffect(.degrees(60), axis: (x:1, y:0, z:0))
            .shadow(color: .gray, radius: 2, x: 0, y: 15)
            .padding()
    }//body
}//ContextView

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
