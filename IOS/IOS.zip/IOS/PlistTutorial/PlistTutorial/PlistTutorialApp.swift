//
//  PlistTutorialApp.swift
//  PlistTutorial
//
//  Created by R C Schweickhardt on 9/24/21.
//

import SwiftUI

@main
struct PlistTutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
