//
//  ContentView.swift
//  PlistTutorial
//
//  Created by R C Schweickhardt on 9/24/21.
//

import SwiftUI

struct ContentView: View {
    
    @State private var personName = ""
    @State private var phoneNumbers = ["","",""]
    
    init() {
        
        if let documentPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            var plistPath = documentPathURL.appendingPathComponent("data.plist").path
            
            if !FileManager.default.fileExists(atPath: plistPath){
                
                plistPath = Bundle.main.path(forResource: "data", ofType: "plist")!
                
            }
            
            print(plistPath)
            
            do {
                
                let data = try Data(contentsOf: URL(fileURLWithPath: plistPath))
                
                let temp = try PropertyListSerialization.propertyList(from: data, options: .mutableContainersAndLeaves, format: nil) as! [String: Any]
                
                print("\(temp)")
                
                self._personName = State(initialValue: temp["Name"] as? String ?? "TBD")
                
                self._phoneNumbers = State(initialValue: temp["Phones"] as? [String] ?? ["TBD","TBD","TBD"])
                
            } catch {
                
                print(error)
                
            }
            
        }//if doc
        
    }//init
    
    var body: some View {
        Text("Hello, world!")
            .padding()
    }//body
}//contentView

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
