//
//  FullScreenBrowserApp.swift
//  FullScreenBrowser
//
//  Created by R C Schweickhardt on 8/24/21.
//

import SwiftUI

@main
struct FullScreenBrowserApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
