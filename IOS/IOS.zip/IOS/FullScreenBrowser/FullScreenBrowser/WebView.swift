//
//  WebView.swift
//  WebView
//
//  Created by R C Schweickhardt on 8/24/21.
//

import Foundation
import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    
    var url: String //passed in when WebView is created
    
    func makeUIView(context: Context) -> WKWebView {
        
        //return actual view we are going to show
        guard let url = URL(string: self.url) else {
           //return empty view
            return WKWebView()
        }//guard
        
        let request = URLRequest(url: url)
        let wKWebView = WKWebView()
        wKWebView.load(request)
        return wKWebView
    }//func
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        //required but we are ignoring
    }
}//WebView
