package com.french.bryan.apiviewer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.AsyncTask
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import android.text.Html
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat.getSystemService
import com.french.bryan.apiviewer.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.lang.Exception
import java.lang.IllegalStateException
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL

class MainActivity : AppCompatActivity() {

    val apiURL = "https://icanhazdadjoke.com/"

    var okHttpClient: OkHttpClient = OkHttpClient()

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.okHttpBtn.setOnClickListener { loadRandomJoke() }

        binding.coroutinesBtn.setOnClickListener { loadRandomJokeCoroutines() }

        binding.asyncTaskBtn.setOnClickListener { loadRandomJokeAsyncTask() }

    } //onCreate

    private fun loadRandomJoke() {
        if(isNetworkConnected()) {
            runOnUiThread {
                binding.progressBar.visibility = View.VISIBLE
            }

            val request: Request = Request.Builder().url(apiURL)
                .addHeader("Accept", "application/json")
                .build()

            okHttpClient.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {

                }

                override fun onResponse(call: Call, response: Response) {
                    val json = response?.body?.string()
                    val txt = (JSONObject(json).get("joke")).toString()

                    //we are on background thread, we need to update
                    //on the main thread
                    runOnUiThread {
                        binding.progressBar.visibility = View.GONE

                        if (Build.VERSION.SDK_INT >=
                            Build.VERSION_CODES.N
                        ) {
                            binding.joke.text = Html.fromHtml(txt, Html.FROM_HTML_MODE_LEGACY)
                        } else {
                            binding.joke.text = Html.fromHtml(txt)
                        }
                    }
                }

            })
        } else {
            AlertDialog.Builder(this)
                .setTitle("No Internet Connection")
                .setMessage("Please check your Internet connection and try again")
                .setPositiveButton(android.R.string.ok) {_,_ ->}
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show()
        }
    }//loadRandomJoke

    private fun loadRandomJokeCoroutines() {

        //Main so we can update GUI
        GlobalScope.launch(Dispatchers.Main) {
            try {
                //turn on progress view
                binding.progressBar.visibility = View.VISIBLE

                var result = ""

                //IO so network on background thread
                withContext(this.coroutineContext + Dispatchers.IO) {
                    result = fetchJokeBlocking() //wait for result
                }

                //process data on UI thread
                if (Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.N) {
                    binding.joke.text = Html.fromHtml(result, Html.FROM_HTML_MODE_LEGACY)
                } else {
                    binding.joke.text = Html.fromHtml(result)
                }

            } catch (e: Exception) {

            }
            finally {
                binding.progressBar.visibility = View.GONE
            }
        }//launch
    }//loadRandomJokeCoroutines

    private fun fetchJokeBlocking(): String {

        var urlConnection: HttpURLConnection? = null
        var txt = "Problem with Connection"

        try {

            val webServiceURL = URL(apiURL)

            urlConnection = webServiceURL.openConnection()
                as HttpURLConnection

            urlConnection.setRequestProperty("Accept", "application/json")
            val responseCode = urlConnection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                txt = "Problem with request"
            } else {
                val bufferedReader = BufferedReader(
                    InputStreamReader(urlConnection.inputStream))

                val stringBuilder = StringBuilder()
                var line: String? = bufferedReader.readLine()
                while (line!=null) {
                    stringBuilder.append(line).append("\n")
                    line = bufferedReader.readLine()
                }
                bufferedReader.close()
                txt = (JSONObject(stringBuilder.toString())
                    .get("joke")).toString()
            }

        } catch (e: MalformedURLException) {
            Log.v("DAD JOKE", e.toString())
        } catch (e: IOException) {
            Log.v("DAD JOKE", e.toString())
        } catch (e: IllegalStateException) {
            Log.v("DAD JOKE", e.toString())
        } finally {
            urlConnection?.disconnect()
            return txt
        }

    }//fetchJokeBlocking

    private fun loadRandomJokeAsyncTask() {
        //load joke info on background thread
        ReadDadJokeTask().execute(apiURL)
    }//loadRandomJokeAsyncTask

    inner class ReadDadJokeTask(): AsyncTask<String, Void, String>() {

        override fun onPreExecute() {
            //on foreground thread
            binding.progressBar.visibility = View.VISIBLE
        }

        override fun onPostExecute(result: String?) {
            //on foreground thread
            if (Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.N) {
                binding.joke.text = Html.fromHtml(result!!, Html.FROM_HTML_MODE_LEGACY)
            } else {
                binding.joke.text = Html.fromHtml(result!!)
            }
            binding.progressBar.visibility = View.GONE
        }

        override fun doInBackground(vararg myURL: String?): String {
            return fetchJokeBlocking()
        }

    }//ReadDadJokeTask

    private  fun isNetworkConnected(): Boolean {

        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE)
            as ConnectivityManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val nw = connectivityManager.activeNetwork ?: return false
            val actNw = connectivityManager.getNetworkCapabilities(nw) ?: return false
            return when {

                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false

            }

        } else {
            val nwInfo = connectivityManager.activeNetworkInfo ?: return false
            return nwInfo.isConnected
        }//if/else

    }//isNetworkConnected

}//MainActivity
